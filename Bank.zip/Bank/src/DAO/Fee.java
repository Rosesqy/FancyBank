package DAO;

/*
 * To provide methods to charge fees on different actions
 */

public interface Fee {
	//Charge fee to transfer from a checking account 
}
