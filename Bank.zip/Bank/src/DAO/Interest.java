package DAO;

/*
 * To pay or charge interest on deposit or loan
 */

public interface Interest {

}
