package Customer;

import java.util.List;

/*
 * The system of the fancy bank to allow its manager and customers to operate through
 */

public class BankSystem {
	//private Manager manager; //A bank system
	//private List<Customer> customers;
}
